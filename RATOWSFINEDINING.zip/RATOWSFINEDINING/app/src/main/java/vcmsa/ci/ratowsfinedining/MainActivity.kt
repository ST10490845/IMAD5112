package vcmsa.ci.ratowsfinedining

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {


   var enter:EditText?=null
   var displaySug:Button?=null      // This line on the code display th menu of the day
   var clear:Button?=null           // This works to clear up the invalid input that the users put
   var output:TextView?=null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        enter = findViewById<View>(R.id.enter) as EditText
        displaySug = findViewById<View>(R.id.display) as Button
        clear = findViewById<View>(R.id.clear) as Button
        output = findViewById<View>(R.id.output) as TextView

        displaySug!!.setOnClickListener{

            val enter = enter!!.text.toString()
            val mealtype :String

            if (enter == "Morning"){

                mealtype = "Cereals\nPancakes & Maple Syrup\nScrambled Eggs & Chicken Sausages\nAvocado Toast\nMuffins\nCroissants & Bacon"
            }

            else if(enter == "Mid Morning Snack"){

                mealtype = "Apple Slices\nYogurt with Fruits\nDried Fruits\nHard-Boiled egg\nSmoothies\nBerries"
            }

            else if(enter == "Afternoon Lunch"){

                mealtype = "Rice Salads\nEgg and Tomato Sandwich\nChicken Wraps and SoftDrinks\nMeatballs & Tomato Soup\nChicken Satay Salad\nFish & Chips"
            }

            else if(enter == "Afternoon Snack"){

                mealtype = "Dark Chocolate and Almonds\nNuts\nHoney-Roasted Peanuts\nCarrot & Turning Strips with Hummus\nPopcorn\nPita Crackers"
            }

            else if(enter == "Dinner"){

                mealtype = "instant Pot Ground Beef and Pasta\nCheesy Lasagna\nChicken and Garlic Bread\nPork Chops\nSpicy KingFish Carry\n Ribs & Rice"
            }

            else if(enter == "Dinner Snack"){

                mealtype = "Ice Cream\nCustard and Jelly\nCheese Cake\nCottage Pie\nBanana Pudding\nChocolate Cake"
            }

            else{

                mealtype = "Invalid Input,Please enter the correct time of the day"
            }

            output!!.text = mealtype


        }


           clear !!.setOnClickListener{
               enter!!.setText("")
                output!!.text = ""
            }















        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }